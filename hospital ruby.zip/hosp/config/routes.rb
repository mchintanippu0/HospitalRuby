Rails.application.routes.draw do

  devise_for :admin_users, ActiveAdmin::Devise.config
  ActiveAdmin.routes(self)
  devise_for :users, controllers: { sessions: 'users/sessions', registrations: 'users/registrations' }
  root 'home#index'

  resources :appointments do 
    collection do
      get :patients
    end
  end

  resources :users, only: [:index] do
    collection do
      get :dashboard
    end
    member do
      get :invoices
    end
  end

  resources :home, only: [:index] do
  	collection do
  		get :services
      get :about_us
  	end
  end

  resources :bills

end
