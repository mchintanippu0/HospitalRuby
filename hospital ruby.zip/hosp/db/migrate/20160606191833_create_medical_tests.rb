class CreateMedicalTests < ActiveRecord::Migration
  def change
    create_table :medical_tests do |t|
      t.string :name
      t.float :fee

      t.timestamps null: false
    end
  end
end
