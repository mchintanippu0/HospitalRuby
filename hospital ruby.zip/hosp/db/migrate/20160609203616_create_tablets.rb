class CreateTablets < ActiveRecord::Migration
  def change
    create_table :tablets do |t|
      t.integer :appointment_id
      t.integer :medication_id
      t.timestamps null: false
    end
  end
end
