class RemoveAppointmentTimeFromAppointment < ActiveRecord::Migration
  def change
    remove_column :appointments, :appointment_time, :time
  end
end
