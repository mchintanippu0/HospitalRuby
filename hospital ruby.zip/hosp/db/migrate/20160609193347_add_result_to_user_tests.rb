class AddResultToUserTests < ActiveRecord::Migration
  def change
    add_column :user_tests, :result, :boolean, default: true
  end
end
