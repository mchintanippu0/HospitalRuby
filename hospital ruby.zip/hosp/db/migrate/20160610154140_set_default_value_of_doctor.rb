class SetDefaultValueOfDoctor < ActiveRecord::Migration
  def change
  	change_column :users, :is_doctor, :boolean ,default: false
  end
end
