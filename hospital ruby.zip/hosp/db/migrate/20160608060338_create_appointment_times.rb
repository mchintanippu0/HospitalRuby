class CreateAppointmentTimes < ActiveRecord::Migration
  def change
    create_table :appointment_times do |t|
      t.string :time

      t.timestamps null: false
    end
  end
end
