class AddColumnsToPhysicians < ActiveRecord::Migration
  def change
    add_column :physicians, :email, :string
    add_column :physicians, :phone_no, :string
    add_column :physicians, :specialty, :string
  end
end
