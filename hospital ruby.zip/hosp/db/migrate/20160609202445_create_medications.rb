class CreateMedications < ActiveRecord::Migration
  def change
		create_table :medications do |t|
			t.string :name
			t.string :description
		  t.timestamps null: false
		end

		Medication.create([
			{name: "Lipitor", description: "a cholesterol-lowering statin drug "},
			{name: "Nexium", description: "an antacid drug"},
			{name: "Plavix", description: "a blood thinner "},
			{name: "Advair Diskus", description: "an asthma inhaler "},
			{name: "Abilify", description: "an antipsychotic drug"},
			{name: "Seroquel", description: "an antipsychotic drug"},
			{name: "Singulair", description: "an oral asthma drug"},
			{name: "Crestor", description: "a cholesterol-lowering statin drug"},
			{name: "Actos", description: "a diabetes drug" },
			{name: "Epogen", description: "an injectable anemia drug" }])
  end
end