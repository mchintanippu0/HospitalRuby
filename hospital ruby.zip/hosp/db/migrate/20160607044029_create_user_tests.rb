class CreateUserTests < ActiveRecord::Migration
  def change
    create_table :user_tests do |t|
      t.references :user, index: true, foreign_key: true
      t.references :appointment, index: true, foreign_key: true
      t.references :medical_test, index: true, foreign_key: true
      t.float :price

      t.timestamps null: false
    end
  end
end
