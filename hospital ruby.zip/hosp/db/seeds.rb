AdminUser.create!(email: 'admin@example.com', password: 'password', password_confirmation: 'password', username: "admin") unless AdminUser.find_by_email("admin@example.com").present?

User.create!(username: 'test-2', email: "test-2@email.com", password: "password") unless User.find_by_email("test-2@email.com").present?
User.create!(username: 'test-3', email: "test-3@email.com", password: "password") unless User.find_by_email("test-3@email.com").present?

User.create!(username: 'Smith',  email: "smith@gmail.com", password: "password", is_doctor: true) unless User.find_by_email("smith@gmail.com").present?
User.create!(username: 'Eric',  email: "eric@gmail.com", password: "password", is_doctor: true) unless User.find_by_email("eric@gmail.com").present?
User.create!(username: 'John',  email: "John@gmail.com", password: "password", is_doctor: true) unless User.find_by_email("John@gmail.com").present?
User.create!(username: 'Kriss',  email: "Kriss@gmail.com", password: "password", is_doctor: true) unless User.find_by_email("kriss@gmail.com").present?
User.create!(username: 'David',  email: "david@gmail.com", password: "password", is_doctor: true) unless User.find_by_email("david@gmail.com").present?

MedicalTest.create!(name: "Liver function tests", fee: 700) unless MedicalTest.find_by_name("Liver function tests").present?
MedicalTest.create!(name: "Cardiopulmonary resuscitation", fee: 1200) unless MedicalTest.find_by_name("Cardiopulmonary resuscitation").present?
MedicalTest.create!(name: "C-reactive protein", fee: 400) unless MedicalTest.find_by_name("C-reactive protein").present?
MedicalTest.create!(name: "Magnetic resonance imaging", fee: 600) unless MedicalTest.find_by_name("Magnetic resonance imaging").present?
MedicalTest.create!(name: "Complete blood count", fee: 200) unless MedicalTest.find_by_name("Complete blood count").present?
MedicalTest.create!(name: "White blood cell", fee: 300) unless MedicalTest.find_by_name("White blood cell").present?
MedicalTest.create!(name: "Post-traumatic stress syndrome", fee:1000) unless MedicalTest.find_by_name("Post-traumatic stress syndrome").present?
MedicalTest.create!(name: "Low density lipoprotein", fee: 1700) unless MedicalTest.find_by_name("Low density lipoprotein").present?
MedicalTest.create!(name: "Attention deficit hyperactivity disorder", fee: 2000) unless MedicalTest.find_by_name("Attention deficit hyperactivity disorder").present?
MedicalTest.create!(name: "Coronary artery disease", fee: 100) unless MedicalTest.find_by_name("Coronary artery disease").present?
MedicalTest.create!(name: "Cytomegalovirus", fee: 150) unless MedicalTest.find_by_name("Cytomegalovirus").present?
MedicalTest.create!(name: "Electrocardiogram", fee: 800) unless MedicalTest.find_by_name("Electrocardiogram").present?

AppointmentTime.create!(time: "8am to 9am")
AppointmentTime.create!(time: "9am to 10am")
AppointmentTime.create!(time: "10am to 11am")
AppointmentTime.create!(time: "12pm to 1pm")
AppointmentTime.create!(time: "1pm to 2pm")
AppointmentTime.create!(time: "2pm to 3pm")
AppointmentTime.create!(time: "3pm to 4pm")
