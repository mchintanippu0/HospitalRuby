class Medication < ActiveRecord::Base

	has_many   :tablets
  has_many   :appointments, through: :tablets, dependent: :destroy
end
