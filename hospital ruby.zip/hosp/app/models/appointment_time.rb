class AppointmentTime < ActiveRecord::Base
  belongs_to :appointment
end
