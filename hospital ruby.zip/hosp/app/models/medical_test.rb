class MedicalTest < ActiveRecord::Base
end
