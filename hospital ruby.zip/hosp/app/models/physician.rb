class Physician < ActiveRecord::Base
  has_many :appointments
  has_many :users, through: :appointments

  validates :name, :phone_no,presence: true
  validates :email, uniqueness: {message: "already taken"}
end
