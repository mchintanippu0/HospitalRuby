class Bill < ActiveRecord::Base
  
  belongs_to :user
  belongs_to :appointment

  def calcultae_total_amount
  	appointment.user_tests.sum(:price)+100
  end

end
