class Tablet < ActiveRecord::Base

	belongs_to :appointment
	belongs_to :medication
end
