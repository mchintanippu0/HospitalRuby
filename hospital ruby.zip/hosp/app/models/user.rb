class User < ActiveRecord::Base
  # Include default devise modules. Others available are:
  # :confirmable, :lockable, :timeoutable and :omniauthable
  devise :database_authenticatable, :registerable,
         :recoverable, :rememberable, :trackable, :validatable
  has_many :appointments
  has_many :bills
  has_many :checkups, foreign_key: "physician_id", class_name: "Appointment"
  # has_many :physicians, through: :appointments
  scope  :doctor, ->{where(is_doctor: true)}

  def medicines
  	Medication.joins(appointments: :user).where("appointments.appointment_date < ? && appointments.user_id = ?", Date.today, self.id).uniq
  end

  def tests
  	UserTest.joins(appointment: :user).where("appointments.appointment_date < ? && appointments.user_id = ?", Date.today, self.id).uniq
  end

  def medical_histroy
  	appointments.expeired_appointment
  end
end
