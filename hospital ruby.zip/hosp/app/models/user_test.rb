class UserTest < ActiveRecord::Base
  belongs_to :user
  belongs_to :appointment
  belongs_to :medical_test
end
