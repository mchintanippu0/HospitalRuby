class Appointment < ActiveRecord::Base
  belongs_to :user
  belongs_to :patient, foreign_key: "id", class_name: "User"
  belongs_to :physician, foreign_key: "physician_id", class_name: "User"
  has_many   :tablets
  has_many   :medications, through: :tablets, dependent: :destroy
  has_many   :user_tests, dependent: :destroy
  has_one    :bill, dependent: :destroy
  has_one    :appointment_time
  validates  :physician_id, presence: true
  validate   :validat_appointment_timing
  after_create :set_user_test, :create_bill, :assign_tablets

  scope :expeired_appointment, ->{where("DATE(appointment_date) <= ?", Date.today - 1)}


  def validat_appointment_timing
    errors.add(:appointment_time, 'is already taken') if Appointment.exists?(appointment_date:  self.appointment_date, appointment_time_id: self.appointment_time_id)

  end

  def set_user_test
    user_tests1 = []
    for i in 0..5
       mTest = MedicalTest.find(rand(1..12))
       self.user_tests.create(user: self.user, medical_test: mTest, price: mTest.fee, result: rand(0..1)) unless UserTest.exists?(appointment: self, user: self.user, medical_test_id: mTest)
    end
  end

  def create_bill
    self.build_bill(user: self.user).save!
  end

  def assign_tablets
    user_tests1 = []
    for i in 0..5
       mTest = Medication.find(rand(1..10))
       self.tablets.create(medication_id: mTest.id)
    end
  end

end
