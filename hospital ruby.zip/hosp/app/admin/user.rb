ActiveAdmin.register User, as: "Patient" do

permit_params :username, :email, :password

end
