ActiveAdmin.register Physician do

permit_params :name, :email, :phone_no, :specialty

end
