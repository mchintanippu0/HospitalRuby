class UsersController < ApplicationController
	layout "user"
  def index
  	@current_nav = "dashboards"
  end

  def dashboard
  	@current_nav = "dashboards"
    @medications =  current_user.medicines
    @tests = current_user.tests
    @appointments = current_user.is_doctor? ? current_user.checkups : current_user.medical_histroy
  
  end

  def invoices
  	# @current_nav = "bills"
   #  @bills = current_user.bills
  end
end
