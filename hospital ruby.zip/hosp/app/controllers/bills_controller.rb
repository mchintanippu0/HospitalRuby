class BillsController < InheritedResources::Base
  

  layout "user"
  before_action :set_nav
  before_action :set_bill, except: [:index]
  before_action :set_user_test, only: [:show]
  

  def index
    @bills = current_user.bills
  end

  private
    def set_bill
      @bill = Bill.find(params[:id])
    end

    def set_user_test
      test_ids = @bill.appointment.user_tests.pluck(:medical_test_id)
      @user_test = MedicalTest.find(test_ids)
    end

    def set_nav
      @current_nav = "bills"
    end

end
