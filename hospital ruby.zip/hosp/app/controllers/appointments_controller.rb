class AppointmentsController < InheritedResources::Base

  layout "user"

  before_action :authenticate_user!
  before_action :set_appointments, only: [:index]
  before_filter :set_nav

  def index

  end

  def create
    @appointment = current_user.appointments.new(appointment_params)
     Appointment.transaction do
      respond_to do |format|
        if @appointment.save
          format.html { redirect_to appointments_path, notice: 'Appointment IS SUCCESSFULLY CREATED.'}
          format.json { render :show, status: :created, location: @appointment }
        else
          format.html { render :new }
          format.json { render json: @appointment.errors, status: :unprocessable_entity }
        end
      end
    end
  end

  def patients
    @patients = current_user.checkups
  end

  # def update
  #   @appointment = Appointment.find(params[:id])
  #   @appointment.update_attributes(appointment_params)
  #   redirect_to appointments_path, notice: 'Appointment UPDATED SUCCESSFULLY.'
  # end

  private

    def appointment_params
      params.require(:appointment).permit(:physician_id, :appointment_date,:appointment_time_id)
    end

    def set_nav
      @current_nav = "appointments"
    end

    def set_appointments
      @appointments = current_user.is_doctor? ? current_user.checkups : current_user.appointments
    end
end
