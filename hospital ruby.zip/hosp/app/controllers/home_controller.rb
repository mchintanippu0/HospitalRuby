class HomeController < ApplicationController
  
  def index
  	@current_nav = "home"
  end

  def services
  	@current_nav = "services"
  end

  def about_us
  	@current_nav = "about_us"
  end
end
