module ApplicationHelper
	def check_appointment_date?(appointment)
    appointment.appointment_date.to_date < Date.today.to_date
  end
end
