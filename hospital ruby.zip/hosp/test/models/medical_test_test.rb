require 'test_helper'

class MedicalTestTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
